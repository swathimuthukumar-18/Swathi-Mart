package com.swathimart.swathi_mart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwathiMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwathiMartApplication.class, args);
	}

}
